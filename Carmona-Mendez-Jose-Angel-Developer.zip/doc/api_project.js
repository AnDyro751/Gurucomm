define({
  "name": "test_api_4",
  "version": "0.1.0",
  "description": "apiDoc",
  "title": "API Docs",
  "url": "http://localhost:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-05-14T16:20:32.941Z",
    "url": "https://apidocjs.com",
    "version": "0.27.1"
  }
});
