require "rails_helper"

RSpec.describe ApplicationMailer, type: :mailer do
end
