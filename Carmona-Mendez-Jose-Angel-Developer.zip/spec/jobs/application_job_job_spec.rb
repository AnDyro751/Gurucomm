require 'rails_helper'

RSpec.describe ApplicationJob, type: :job do
end
