require 'rails_helper'

RSpec.describe ApplicationCable::Channel, type: :channel do
end
