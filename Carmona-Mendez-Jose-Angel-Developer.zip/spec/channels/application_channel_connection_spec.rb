require 'rails_helper'

RSpec.describe ApplicationCable::Connection, type: :channel do
end
