require 'rails_helper'

RSpec.describe ApplicationController do
end
